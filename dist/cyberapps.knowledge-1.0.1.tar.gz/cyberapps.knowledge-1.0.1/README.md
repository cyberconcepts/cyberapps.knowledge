# Introduction

This is a an application library for the web application platform
*loops*. It provides functionality for knowledge management
and human resources development.

For more information see
[www.cyberconcepts.org](https://www.cyberconcepts.org).

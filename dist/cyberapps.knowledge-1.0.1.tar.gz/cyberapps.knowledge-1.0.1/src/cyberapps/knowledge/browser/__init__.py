"""
cyberapps.knowledge.browser
"""
